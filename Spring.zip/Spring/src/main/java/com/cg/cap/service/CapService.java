package com.cg.cap.service;

import com.cg.cap.bean.Cap;
import com.cg.cap.exception.CapException;

public interface CapService 
{	

	public void setStatus(int product_id) throws CapException;
	public Cap getStatus(int product_id) throws CapException;	
}
