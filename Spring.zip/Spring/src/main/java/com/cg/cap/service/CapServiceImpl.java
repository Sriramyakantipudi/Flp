package com.cg.cap.service;


import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.cap.bean.Cap;
import com.cg.cap.dao.Dao;
import com.cg.cap.exception.CapException;


@Service
public class CapServiceImpl implements CapService
{
@Autowired
Dao dao;
Date dOfOrderd;
String e;

@Override
public void setStatus(int id) throws CapException {
	
try {
	
	Optional<Cap> c=dao.findById(id);
	if(c.isPresent())
	{
		Cap c1=c.get();
		dOfOrderd=c1.getDateOfOrd();
		int noOfdays=c1.getNoOfDaysForDelivery();
		LocalDate d=java.time.LocalDate.now();
		Date d2=Date.valueOf(d);
		long diff = d2.getTime() - dOfOrderd.getTime();
		long diffDays=TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
		
	    System.out.println(diffDays); 
	     if(diffDays==0)
	     {
	      e="order placed";
	     }
	     if(diffDays <noOfdays)
	     {
	      if(diffDays==1 || diffDays==2)
	      {
	    	 e="order dispatched";
	     }
	     else if(diffDays==3 || diffDays==4 || diffDays==5)
	     {
	    	 e="order shipped";
	     }
	     else if(diffDays==6)
	     {
	    	 e="out for delivery";
	     }
	    
	     }
	     else 
	     {
	    	 e="order delivered";
	     }
	     c1.setStatus(e);
	     dao.save(c1);
	}
	else
	{
		throw new CapException("Please enter valid product_id");
	} 	
  }
catch(Exception e)
    {
        throw new CapException(e.getMessage());
   }
	
}


@Override
public Cap getStatus(int id) throws CapException {
   try
   {
	    Optional<Cap> c=dao.findById(id);
	    Cap c1=null;
	    if(c.isPresent())
	    {
		   setStatus(id);
		   c1=c.get();
		  return c1;
	   }
	
	  else
	  {
		 throw new CapException("Product does not exists");
	  }
  }
   
  catch(Exception e)
   {
      throw new CapException(e.getMessage());
   }	
	
}

}



