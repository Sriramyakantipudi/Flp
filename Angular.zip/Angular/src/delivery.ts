export class Delivery
{
    product_id:number;
    dateOfOrd:Date;
    noOfDaysForDelivery:number;
    status:String
}
